// import dojo modules or your own before you use them; remove these if you
// replace the default layout
dojo.provide('myapp.Main');
dojo.require('dijit._Widget');
dojo.require('dijit.layout.BorderContainer');
dojo.require('dijit.layout.ContentPane');
dojo.require('dijit.layout.AccordionContainer');
dojo.require('dijit.layout.TabContainer');

// adjust the namespace if you changed it in index.html; this widget serves
// as our main controller to do stuff across the whole app and kick off the
// app when the page loads
dojo.declare('myapp.Main', null, {
    constructor: function() {
        // this example code connects an event handler to the tabs and 
        // accordion to show the last selected in the footer area of the page; 
        // replace it with code that makes sense for your own app
        var tabs = dijit.byId('tabs');
        dojo.connect(tabs, '_transition', this, '_onSelectPane');
        var sb = dijit.byId('sidebar');
        dojo.connect(sb, '_transition', this, '_onSelectPane');
        
        // a little template for what we'll show in the footer
        this._msg = 'Selected {newPane}, deselected {oldPane}';
        // store the footer so we don't have to look it up all the time
        this._footer = dojo.byId('footer');
    },
    
    _onSelectPane: function(newPane, oldPane) {
        var text = dojo.replace(this._msg, {
            newPane: newPane.title,
            oldPane: oldPane.title
        });
        this._footer.innerHTML = text;
    }
});

dojo.ready(function() {
    // build our main widget when the page is ready; adjust the name here
    // if you change it above but otherwise leave this alone and do all your
    // work in the widget above
    console.log('here');
    var app = new myapp.Main();
    console.log(app);
});