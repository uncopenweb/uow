{
    start_label : 'Start',
    stop_label  : 'Stop',
    reset_label : 'Reset'
}